// DM2008 — Activity 5a [Guided]
// Colliding Circles (30 min)
//
// A vector stores position and movement together — cleaner than separate x and y variables.
// Your job is to get two balls moving, then detect and respond to their collision.
//
// Suggested order:
// 1. Create two Ball objects in setup()
// 2. Check the distance between them in draw()
// 3. Trigger a visual response when they collide
// 4. Implement edge behaviour in move() — wrap or bounce, your choice
//
// Stretch: add a third ball, or make the collision response affect both balls.

let balls = [];

function setup() {
  createCanvas(400, 400);
  // Create two balls at different starting positions
  balls.push(new Ball(100, 200));
  balls.push(new Ball(300, 200));
}

function draw() {
  background(230);

  // Check collision between the two balls
  // dist() measures the distance between their centers
  // They overlap when that distance is less than the sum of their radii

  let d = dist(balls[0].pos.x, balls[0].pos.y, balls[1].pos.x, balls[1].pos.y);
  let colliding = d < balls[0].r + balls[1].r; // true when the balls overlap, false otherwise

  for (let i = 0; i < balls.length; i++) {
    balls[i].move();
    balls[i].show(colliding);
  }
}

class Ball {
  constructor(x, y) {
    // pos and vel are vectors — they store x and y together as one object
    this.pos = createVector(x, y);
    this.vel = createVector(random(-10, 10), random(-10, 10));
    this.r = 30;
    this.wasColliding = false;
  }

  move() {
    // Adding the velocity vector to position moves the ball each frame
    this.pos.add(this.vel);

    if (this.pos.x + this.r > width || this.pos.x - this.r < 0) {
      this.vel.x *= -1;
    }

    if (this.pos.y + this.r > height || this.pos.y - this.r < 0) {
      this.vel.y *= -1;
    }
  }

  show(colliding) {
    // colliding is true or false — try using it in an if/else to change fill or size
    noStroke();
    if (colliding) {
      triangle(
        this.pos.x,
        this.pos.y - this.r,
        this.pos.x - this.r,
        this.pos.y + this.r,
        this.pos.x + this.r,
        this.pos.y + this.r
      );
      fill(255, 80, 80);
    } else {
      ellipse(this.pos.x, this.pos.y, this.r * 2);
      fill(100, 180, 220);
    }
  }
}
