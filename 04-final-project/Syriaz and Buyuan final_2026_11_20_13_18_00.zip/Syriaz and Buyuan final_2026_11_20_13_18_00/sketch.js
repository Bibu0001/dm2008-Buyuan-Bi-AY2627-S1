let simulationInterval = 1;
let lastUpdate = 0;
let simulationSteps = 0;
let mouseHasBeenClicked;
let cellSize = 20;
let columnCount;
let rowCount;
let currentCells = [];
let nextCells = [];
let eligibleMates = {
  Prey: [],
  Predator: []
};
let selectedCellType = "Plant";
let brushRadius = 0;
let maxBrushRadius = 10;

const DIRECTIONS = [
  { x: 0, y: -1 }, // Up
  { x: 0, y: 1 },  // Down
  { x: -1, y: 0 }, // Left
  { x: 1, y: 0 }   // Right  
];

const PLANT_DIRECTIONS = [
  { x: 0, y: -1 },  // Up
  { x: 0, y: 1 },   // Down
  { x: -1, y: 0 },  // Left
  { x: 1, y: 0 },   // Right

  { x: -1, y: -1 }, // Up-left
  { x: 1, y: -1 },  // Up-right
  { x: -1, y: 1 },  // Down-left
  { x: 1, y: 1 }    // Down-right
];



function setup() {

  // -- Canvas setup stuff
  
  let canvas = createCanvas(1500, 1500);

  // Allow the canvas to receive keyboard input
  canvas.elt.tabIndex = 0;

  // Give canvas keyboard focus when clicked
  canvas.elt.addEventListener("pointerdown", () => {
  canvas.elt.focus();
  });

  // Disable right-click context menu
  canvas.elt.addEventListener("contextmenu", event => {
    event.preventDefault();
  });

  describe("A 1500 by 1500 pixel ecosystem simulation.");

  // --

  // Calculate grid dimensions
  columnCount = floor(width / cellSize);
  rowCount = floor(height / cellSize);

  
  for (let column = 0; column < columnCount; column++) {
    currentCells[column] = [];
    nextCells[column] = [];
  }


  randomiseBoard();

  mouseHasBeenClicked = true;

  frameRate(30);
  loop();
}



function draw() {

  background(220);

  if (mouseHasBeenClicked === true) {
    if (millis() - lastUpdate >= simulationInterval) {
      updateBoard();
      lastUpdate = millis();
    }
  }

  renderBoard();
  renderBrush();

  // Count the current populations
  let population = countPopulation();

  // Display statistics
  fill(0);
  noStroke();
  textSize(16);
  textAlign(LEFT, TOP);

  text("Simulation Steps: " + simulationSteps, 10, 10);

  text("Plants: " + population.plants, 10, 30);

  text("Prey: " + population.prey, 10, 50);

  text("Predators: " + population.predators, 10, 70);

  text(
  "Total Animals: " + (population.prey + population.predators),
  10,
  90
  );

  text("Selected: " + selectedCellType, 10, 110);
  text("Brush Radius: " + brushRadius, 10, 130);
}


function mousePressed(event) {

  // Ignore clicks outside the canvas
  if (
    mouseX < 0 || mouseX >= width ||
    mouseY < 0 || mouseY >= height
  ) {
    return;
  }

  if (event.button === 0) {
    // Left click: spawn
    paintCells(false);
  }

  if (event.button === 2) {
    // Right click: delete
    paintCells(true);
  }

  return false;
}



function randomiseBoard() {

  let preyClusters = createClusters(6);
  let predatorClusters = createClusters(3);

  // Controls the size of fertile regions
  let fertilityNoiseScale = 0.08;

  // Controls how much of the world is fertile
  let fertilityThreshold = 0.45;

  // Generate a different fertility map each reset
  noiseSeed(floor(random(1000000)));

  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) {

      // Generate terrain fertility
      let fertilityNoise = noise(
        column * fertilityNoiseScale,
        row * fertilityNoiseScale
      );

      let fertility = fertilityNoise > fertilityThreshold
        ? 1
        : 0;

      // Animal spawning probabilities
      let preyChance = getClusterChance(
      column,
      row,
      preyClusters,
      8,
      animalSpawnOptions[0].chance
      );

      let predatorChance = getClusterChance(
      column,
      row,
      predatorClusters,
      10,
      animalSpawnOptions[1].chance
      );

      let animal = null;

      if (random(1) < predatorChance) {
        animal = new Predator();
      } else if (random(1) < preyChance) {
        animal = new Prey();
      }

      currentCells[column][row] = {

        fertility: fertility,

        plant: fertility === 1 && random(1) < 0.4
          ? new Plant()
          : null,

        animal: animal

      };
    }
  }
}


function renderBoard() {
  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) { 
      let cell = currentCells[column][row];

      let x = column * cellSize;
      let y = row * cellSize

      rectMode(CORNER);
      
      if (cell.plant !== null) {
      fill(0, 200, 0);         // Plants
      } else if (cell.fertility === 1) {
      fill(190, 220, 170);     // Fertile ground
      } else {
      fill(200, 180, 150);     // Infertile ground
      }

      stroke(0);
      rect(x, y, cellSize, cellSize)
      
      if(cell.animal !== null) {

        if (cell.animal.cellType === "Prey") {
          fill(0, 0, 255);
        } else if (cell.animal.cellType === "Predator") {
          fill (255, 0, 0);
        }

      let centerX = x + cellSize / 2;
      let centerY = y + cellSize / 2;

      rectMode(CENTER);
        
      stroke(0);
        
      rect(centerX, centerY, cellSize * 0.65, cellSize * 0.65);      
      }
    }
  }
}

function updateBoard() {
  nextCells = currentCells.map(column => column.map(
    cell => ({...cell})
    )
  ); //Duplicates the currentCells array and creates nextCells array with the same elements. Both arrays are pointing at different values.

  updateEligibleMates();
  
  //Plant Pass
  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) {

      let plant = currentCells[column][row].plant;

      if (plant === null) {
        continue;
      }

      updatePlant(column, row, plant);

    }
    
  }

  regeneratePlants();
  
  //Animal Pass
  for (let column = 0; column < columnCount; column ++) {
    for (let row = 0; row < rowCount; row ++) {

      let animal = currentCells[column][row].animal;

      if (animal === null) {
        continue;
      }

      // If animal cell has moved or died already, skip.
      if (nextCells[column][row].animal !== animal) {
        continue;
      }

      if (animal.cellType !== "Prey") {
        continue;
      }

      animal.updateHunger();
      animal.updateReproduction();
      animal.updateAge();

      //If animal can eat, check if they are standing on a plant.
      
      if (
        animal.canEat() &&
        nextCells[column][row].plant !== null
      ) {
        animal.eat();
        nextCells[column][row].plant = null; // Eat plant
      }

      if (animal.isStarving() || animal.isOld()) {
        nextCells[column][row].animal = null;
        continue;
      }
      
      let destination = animal.getMovement(column, row);

      let newX = destination.x;
      let newY = destination.y;

      if (newX === column && newY === row) {
        continue;
      }

      if (!canAnimalMoveTo(newX, newY)) {
        continue;
      }

      nextCells[column][row].animal = null;
      nextCells[newX][newY].animal = animal;

    if (animal.canEat() &&
       nextCells[newX][newY].plant !== null
       ) {
      animal.eat();
      nextCells[newX][newY].plant = null;
    }
  }
}

  //Predator Pass
  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) {

      let predator = currentCells[column][row].animal;

      // Only process predators
      if (
        predator === null ||
        predator.cellType !== "Predator"
      ) {
        continue;
      }

      // Skip predators that have already moved
      if (nextCells[column][row].animal !== predator) {
        continue;
      }

      predator.updateHunger();
      predator.updateAge();
      predator.updateReproduction();

      // Try eating from the current position
      if (tryEatPrey(column, row, predator)) {
        continue;
      }

      // Death from starvation or old age
      if (predator.isStarving() || predator.isOld()) {
        nextCells[column][row].animal = null;
        continue;
      }

      // Decide where to move
      let destination = predator.getMovement(column, row);

      let newX = destination.x;
      let newY = destination.y;

      // Predator remains in the same position
      if (newX === column && newY === row) {
        continue;
      }

      // Check whether destination is available
      if (!canAnimalMoveTo(newX, newY)) {
        continue;
      }

      // Move predator
      nextCells[column][row].animal = null;
      nextCells[newX][newY].animal = predator;

      // Try attacking after moving
      tryEatPrey(newX, newY, predator);
    }
  }

  

  // Reproduction Pass
for (let column = 0; column < columnCount; column++) {
  for (let row = 0; row < rowCount; row++) {

    let animal = nextCells[column][row].animal;

    if (animal === null) {
      continue;
    }

    if (
      animal.cellType !== "Prey" &&
      animal.cellType !== "Predator"
    ) {
      continue;
    }

    if (animal.canReproduce()) {
      tryReproduce(column, row, animal);
    }
  }
}
  
  currentCells = nextCells;

  simulationSteps++;
}


function createClusters(count) {

  let clusters = [];

  for (let i = 0; i < count; i++) {
    clusters.push({
      x: random(columnCount),
      y: random(rowCount)
    });
  }

  return clusters;
}

function getClusterChance(column, row, clusters, radius, maxChance) {

  let nearestDistance = Infinity;

  for (let cluster of clusters) {

    let distance = dist(
      column,
      row,
      cluster.x,
      cluster.y
    );

    nearestDistance = min(nearestDistance, distance);
  }

  let strength = max(
    0,
    1 - nearestDistance / radius
  );

  return maxChance * strength;
}

function randomiseClass() {

  let totalWeight = 0;


  // We are just tallying up the total weight from all the .weights from each object in our spawnOptions const array.
  for (let option of animalSpawnOptions) {
    totalWeight += option.weight
  }

  let roll = random(totalWeight);

  for (let option of animalSpawnOptions) {

    if (roll < option.weight) {
      return option.type === null ? null : new option.type();
    }

    roll -= option.weight;
    
  }

  
  let newClass;
  let cellState;
  let rollChance = random(1); // Randomises a number from 0 to 1, and we decide the odds of each class being chosen

  if (rollChance < 0.5) {

    return newClass = null;
    
  } else if (rollChance < 0.5 + 0.5 * 7/10) {
    
    return newClass = new Plant;
    
  } else if (rollChance < 0.5 + 0.5 * 9/10) {
    
    return newClass= new Prey;
    
  }  else {
    
    return newClass = new Predator;
  }
}

function canAnimalMoveTo(column, row) {
  if (
    column < 0 ||
    column >= columnCount ||
    row < 0 ||
    row >= rowCount
  ) {
    return false;
  }

  if (currentCells[column][row].animal !== null) {
    return false;
  }

  if(nextCells[column][row].animal !==null) {
    return false;
  }

  return true;

  //We check both the current state of the board if there is a cell there, as well the future state of the board if any other cell has occupied that spot.
}

function getNeighbours (column, row, directions = DIRECTIONS) {

  let neighbours = [];

  for (let direction of directions) {

    let newX = column + direction.x;
    let newY = row + direction.y;

    if (
      newX < 0 || newX >= columnCount ||
      newY < 0 || newY >= rowCount
    ) {
      continue;
    }

    neighbours.push({
      x: newX,
      y: newY
    });
  }
  return neighbours;
}

function updatePlant(column, row, plant) {

  let neighbours = getNeighbours(
    column,
    row,
    PLANT_DIRECTIONS
  );

  let emptyCells = [];

  for (let position of neighbours) {

    let neighbour = nextCells[position.x][position.y];

    // Plants can only reproduce onto fertile,
    // unoccupied plant tiles.
    if (
      neighbour.fertility === 1 &&
      neighbour.plant === null
    ) {
      emptyCells.push(position);
    }
  }

  plant.updateReproduction();

  if (
    plant.canReproduce() &&
    emptyCells.length > 0
  ) {

    let destination = random(emptyCells);

    nextCells[destination.x][destination.y].plant =
      new Plant();

    plant.resetReproduction();
  }
}

function regeneratePlants() {

  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) {

      let cell = nextCells[column][row];

      if (
        cell.fertility === 1 &&
        cell.plant === null &&
        random(1) < 0.0002
      ) {
        cell.plant = new Plant();
      }
    }
  }
}

function tryReproduce(column, row, animal) {
  if (!animal.canReproduce()) {
    return false;
  }

  let mate = null;
  let matePosition = null;

  for (let dx = -animal.reproductionRadius;
      dx <= animal.reproductionRadius; dx++) {

    for (let dy = -animal.reproductionRadius;
        dy <= animal.reproductionRadius; dy++) {

      if(
        Math.abs(dx) + Math.abs(dy) >
        animal.reproductionRadius
      ) {
        continue;
      }

      let newX = column + dx;
      let newY = row + dy;

      if (
        newX < 0 || newX >= columnCount ||
        newY < 0 || newY >= rowCount
      ) {
        continue;
      }

      let other = nextCells[newX][newY].animal;

      if (
        other !== null &&
        other !== animal &&
        other.cellType === animal.cellType &&
        other.canReproduce()
      ) {
        mate = other;
        matePosition = { x: newX, y: newY};
        break;
      }
    }

  if (mate !== null) {
    break;
    }
  }

  if (mate === null) {
    return false;
  }

  let positions = [
    ...getNeighbours(column, row),
    ...getNeighbours(matePosition.x, matePosition.y)
  ];

  let emptyCells = [];

  for (let position of positions) {
    if (
      nextCells[position.x][position.y].animal === null
    ) {
      emptyCells.push(position);
    }
  }

  if (emptyCells.length === 0) {
    return false;
  }

  let destination = random(emptyCells);

  nextCells[destination.x][destination.y].animal =
    new animal.constructor();

  animal.reproduce();
  mate.reproduce();

  return true;
}

function findNearestTarget(       // Our generic BFS search function used in classes.
  startX,
  startY,
  isTarget,
  maxDistance = Infinity,
  targetRange = 0,
  board = currentCells
) {

  let queue = [{       //Array of cells that the BFS will have to evaluate through.
    x: startX,
    y: startY,
    distance: 0,
    firstStep: null
  }];

  let visited = new Uint8Array(columnCount * rowCount);

  visited[startX * rowCount + startY] = 1;

  let index = 0;

  while (index < queue.length) {

    let current = queue[index];
    index++;

    // Check targets within targetRange
    for (let dx = -targetRange; dx <= targetRange; dx++) {
      for (let dy = -targetRange; dy <= targetRange; dy++) {

        // Only check positions within Manhattan distance
        if (Math.abs(dx) + Math.abs(dy) > targetRange) {
          continue;
        }

        let targetX = current.x + dx;
        let targetY = current.y + dy;

        // Check board boundaries
        if (
          targetX < 0 || targetX >= columnCount ||
          targetY < 0 || targetY >= rowCount
        ) {
          continue;
        }

        // Check if the cell contains our target
        if (isTarget(board[targetX][targetY])) {
          return current.firstStep === null
            ? { x: startX, y: startY }
            : current.firstStep;
        }

      } // End dy loop
    } // End dx loop

    // Stop exploring beyond the search radius
    if (current.distance >= maxDistance) {
      continue;
    }

    // Explore neighbouring cells
    for (let direction of DIRECTIONS) {

      let newX = current.x + direction.x;
      let newY = current.y + direction.y;

      // Check board boundaries
      if (
        newX < 0 || newX >= columnCount ||
        newY < 0 || newY >= rowCount
      ) {
        continue;
      }

      let indexPosition = newX * rowCount + newY;

      if (visited[indexPosition] === 1) {
      continue;
      }

      visited[indexPosition] = 1;

      let cell = board[newX][newY];

      // Animals cannot move through occupied cells
      if (cell.animal !== null) {
        continue;
      }

      // Remember the first step from the starting position
      let firstStep = current.firstStep;

      if (firstStep === null) {
        firstStep = { x: newX, y: newY };
      }

      queue.push({
        x: newX,
        y: newY,
        distance: current.distance + 1,
        firstStep: firstStep
      });
    }

  } // End while loop

  // No target found
  return null;
}

function tryEatPrey(column, row, predator) {


  if(!predator.canEat()) {
    return false;
  }

  let neighbours = getNeighbours(column, row);

  for (let position of neighbours) {

    let target = nextCells[position.x][position.y].animal;

    if (
      target!== null &&
      target.cellType === "Prey"
    ) {

      nextCells[position.x][position.y].animal = null;

      predator.eat();

      return true;
      
    }   
  }

  return false;
}


function updateEligibleMates() {

  // Clear previous lists
  eligibleMates.Prey = [];
  eligibleMates.Predator = [];

  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) {

      let animal = nextCells[column][row].animal;

      if (animal === null) {
        continue;
      }

      if (!animal.canReproduce()) {
        continue;
      }

      eligibleMates[animal.cellType].push({
        animal: animal,
        x: column,
        y: row
      });
    }
  }
}

function hasEligibleMate(animal, column, row) {

  let mates = eligibleMates[animal.cellType];

  for (let mate of mates) {

    if (mate.animal === animal) {
      continue;
    }

    if (!mate.animal.canReproduce()) {
      continue;
    }

    let distance =
      abs(mate.x - column) +
      abs(mate.y - row);

    if (distance <= animal.mateSearchRadius) {
      return true;
    }
  }

  return false;
}

function countPopulation() {

  let plants = 0;
  let prey = 0;
  let predators = 0;

  for (let column = 0; column < columnCount; column++) {
    for (let row = 0; row < rowCount; row++) {

      let cell = currentCells[column][row];

      if (cell.plant !== null) {
        plants++;
      }

      if (cell.animal !== null) {

        if (cell.animal.cellType === "Prey") {
          prey++;
        } else if (cell.animal.cellType === "Predator") {
          predators++;
        }
      }
    }
  }

  return { plants, prey, predators };
}

function getBrushCells() {

  let cells = [];

  let centerX = floor(mouseX / cellSize);
  let centerY = floor(mouseY / cellSize);

  // Mouse must be inside the canvas
  if (
    centerX < 0 || centerX >= columnCount ||
    centerY < 0 || centerY >= rowCount
  ) {
    return cells;
  }

  for (let dx = -brushRadius; dx <= brushRadius; dx++) {
    for (let dy = -brushRadius; dy <= brushRadius; dy++) {

      // Circular selection
      if (dx * dx + dy * dy > brushRadius * brushRadius) {
        continue;
      }

      let x = centerX + dx;
      let y = centerY + dy;

      if (
        x < 0 || x >= columnCount ||
        y < 0 || y >= rowCount
      ) {
        continue;
      }

      cells.push({ x, y });
    }
  }

  return cells;
}

function renderBrush() {

  let cells = getBrushCells();

  push();

  rectMode(CORNER);
  fill(255, 255, 255, 65);
  stroke(255, 255, 255);
  strokeWeight(2);

  for (let cell of cells) {
    rect(
      cell.x * cellSize,
      cell.y * cellSize,
      cellSize,
      cellSize
    );
  }

  pop();
}


function mouseWheel(event) {

  // Only change the brush when hovering over canvas
  if (
    mouseX < 0 || mouseX >= width ||
    mouseY < 0 || mouseY >= height
  ) {
    return;
  }

  if (event.deltaY < 0) {
    brushRadius++;
  } else if (event.deltaY > 0) {
    brushRadius--;
  }

  brushRadius = constrain(
    brushRadius,
    0,
    maxBrushRadius
  );

  // Prevent page scrolling
  return false;
}

function paintCells(deleteMode = false) {

  let cells = getBrushCells();

  for (let position of cells) {

    let cell = currentCells[position.x][position.y];

    if (deleteMode) {

      cell.plant = null;
      cell.animal = null;

      continue;
    }

    switch (selectedCellType) {

      case "Plant":
        // Make the ground suitable for plants
        cell.fertility = 1;
        cell.plant = new Plant();
        break;

      case "Prey":
        cell.animal = new Prey();
        break;

      case "Predator":
        cell.animal = new Predator();
        break;
    }
  }
}

function keyPressed(event) {

  console.log("Key pressed:", key);

  switch (key.toLowerCase()) {

    case "1":
      selectedCellType = "Plant";
      break;

    case "2":
      selectedCellType = "Prey";
      break;

    case "3":
      selectedCellType = "Predator";
      break;

    case "r":
      randomiseBoard();
      simulationSteps = 0;
      lastUpdate = millis();

      eligibleMates.Prey = [];
      eligibleMates.Predator = [];
      break;
  }

  return false;
}


// Cell Classes //


class LivingThing {

  constructor() {
    this.cellType;
    this.updated = false;
  }

  randomWalk(column, row) {

  // Respect the animal's movement chance
  if (random(1) >= this.moveChance) {
    return { x: column, y: row };
  }

  // Check whether the destination has been reached
  if (
    this.wanderDestination !== null &&
    column === this.wanderDestination.x &&
    row === this.wanderDestination.y
  ) {
    this.wanderDestination = null;
  }

  // Choose a new destination if necessary
  if (this.wanderDestination === null) {

    for (let attempt = 0; attempt < 10; attempt++) {

      let dx = floor(random(
        -this.wanderMaxDistance,
        this.wanderMaxDistance + 1
      ));

      let dy = floor(random(
        -this.wanderMaxDistance,
        this.wanderMaxDistance + 1
      ));

      let targetX = column + dx;
      let targetY = row + dy;

      let targetDistance = abs(dx) + abs(dy);

      // Check wandering distance
      if (
        targetDistance < this.wanderMinDistance ||
        targetDistance > this.wanderMaxDistance
      ) {
        continue;
      }

      // Check board boundaries
      if (
        targetX < 0 || targetX >= columnCount ||
        targetY < 0 || targetY >= rowCount
      ) {
        continue;
      }

      // Destination must be unoccupied
      if (nextCells[targetX][targetY].animal !== null) {
        continue;
      }

      this.wanderDestination = {
        x: targetX,
        y: targetY
      };

      break;
    }
  }

  // No valid destination found
  if (this.wanderDestination === null) {
    return { x: column, y: row };
  }

  let targetX = this.wanderDestination.x;
  let targetY = this.wanderDestination.y;

  // ---------------------------------
  // OPTIMISATION: Direct movement
  // ---------------------------------

  let currentDistance =
    abs(targetX - column) +
    abs(targetY - row);

  // Randomise direction order to avoid
  // always favouring the same direction
  let directions = shuffle([...DIRECTIONS]);

  // Prioritise directions closer to target
  directions.sort((a, b) => {

    let distanceA =
      abs(targetX - (column + a.x)) +
      abs(targetY - (row + a.y));

    let distanceB =
      abs(targetX - (column + b.x)) +
      abs(targetY - (row + b.y));

    return distanceA - distanceB;
  });

  for (let direction of directions) {

    let newX = column + direction.x;
    let newY = row + direction.y;

    let newDistance =
      abs(targetX - newX) +
      abs(targetY - newY);

    // Move directly if the position is valid
    // and brings us closer to the destination
    if (
      newDistance < currentDistance &&
      canAnimalMoveTo(newX, newY)
    ) {
      return { x: newX, y: newY };
    }
  }

  // ---------------------------------
  // FALLBACK: BFS pathfinding
  // ---------------------------------

  let destination = findNearestTarget(
    column,
    row,
    cell => cell === currentCells[targetX][targetY],
    this.wanderMaxDistance * 2,
    0,
    currentCells
  );

  if (destination !== null) {
    return destination;
  }

  // Destination cannot be reached
  // Choose another target next time
  this.wanderDestination = null;

  return { x: column, y: row };
}
}


class Plant extends LivingThing {
  constructor() {
  super();
  this.cellType = "Plant";

  this.reproductionTimer = 0; // Keeps track of how long since reproduced
  this.reproductionTreshold = floor(random(65, 75)); //Chooses random between 30 & 50, rounds down to lowest interger
  }

  updateReproduction() {
    this.reproductionTimer++; //Increases reproduction timer by 1 each simulation interval.
  }

  resetReproduction() {
    this.reproductionTimer = 0; //Self-explanatory.
  }

  canReproduce() {
    return this.reproductionTimer >= this.reproductionTreshold; //Returns true or false depending if reproductionTimer has surpassed reproductionTreshold.
  }
}

class Prey extends LivingThing {
  constructor() {
  super();
  this.cellType = "Prey";

  this.reproductionTimer = 0;
  this.reproductionTreshold = 132;
  this.reproductionHungerLimit = 58;
  this.reproductionCost = 15;

  this.mateSearchRadius = 16;
  this.reproductionRadius = 2;
    
  this.hunger = 0;
  this.hungerTreshold = 45;
  this.starvationTreshold = 85;
  this.foodSearchRadius = 20;
    
  this.moveChance = 0.2;

  this.fleeChance = 0.70;
  this.predatorDetectionRadius = 7;

  this.wanderDestination = null;

  this.wanderMinDistance = 5;
  this.wanderMaxDistance = 25;    

  this.age = 0;
  this.maxLifespan = floor(random(500, 656));
  }

  //See above in plant, most methods here are similar to plant's.
  
  updateHunger() {
    this.hunger += 1;
  }

  isStarving() {
    return this.hunger > this.starvationTreshold; //If hunger is more than starvation treshold, return true.
  }

  canEat() {
    return this.hunger >= this.hungerTreshold;
  }

  eat() {
    this.hunger = 0;
  }

  updateReproduction() {
    this.reproductionTimer++;
  }

  canReproduce() {
    return (
      this.reproductionTimer >= this.reproductionTreshold && this.hunger <= this.reproductionHungerLimit
    );
  }

  reproduce() {
    this.reproductionTimer = 0;
    this.hunger += this.reproductionCost;
  }

  updateAge() {
    this.age++;
  }

  isOld() {
    return this.age > this.maxLifespan;
  }

  getMovement(column, row) {

  // Priority 0: Escape predators
  let escape = this.getEscapeMovement(column, row);

  if (escape !== null) {

  if (random(1) < this.fleeChance) {
    return escape;
  }

  // Stay still for this step
  return { x: column, y: row };
  }
  
  // Priority 1 - Search for food.
  if (this.canEat()) {


  // callback function to findNearestTarget(). shorthand for a function that determines whether the .plant of a cell (in this case, inside findNearestTarget() passes in the cell parameter) is true or not
    
    let destination = findNearestTarget(
      column,
      row,
      cell => cell.plant !== null, 
      this.foodSearchRadius,
      0
    );

    if (destination !== null) {
      return destination;
    }
  }

  // Priority 2 - Search for mates
  if (
    this.canReproduce() &&
    hasEligibleMate(this, column, row)
  ) {

    let destination = findNearestTarget(
      column,
      row,

      cell =>
        cell.animal !== null &&
        cell.animal !== this &&
        cell.animal.cellType === "Prey" &&    //Essentially same as above, but passing in multiple conditions.
        cell.animal.canReproduce(),

      this.mateSearchRadius,
      this.reproductionRadius
    );

    if (destination !== null) {
      return destination;
    }
  }

  // Priority 3: Random walking
  return this.randomWalk(column, row);
}

  getEscapeMovement(column, row) {

  let radius = this.predatorDetectionRadius;
  let predators = [];

  // Find nearby predators
  for (let dx = -radius; dx <= radius; dx++) {
    for (let dy = -radius; dy <= radius; dy++) {

      if (abs(dx) + abs(dy) > radius) {
        continue;
      }

      let x = column + dx;
      let y = row + dy;

      if (
        x < 0 || x >= columnCount ||
        y < 0 || y >= rowCount
      ) {
        continue;
      }

      let animal = nextCells[x][y].animal;

      if (
        animal !== null &&
        animal.cellType === "Predator"
      ) {
        predators.push({ x, y });
      }
    }
  }

  // No predators nearby
  if (predators.length === 0) {
    return null;
  }

  // Helper: distance to the nearest predator
  function nearestPredatorDistance(x, y) {

    let nearest = Infinity;

    for (let predator of predators) {

      let predatorDistance =
        abs(x - predator.x) +
        abs(y - predator.y);

      nearest = min(nearest, predatorDistance);
    }

    return nearest;
  }

  // Distance from the current position
  let currentDistance =
    nearestPredatorDistance(column, row);

  let safestMoves = [];
  let bestDistance = -Infinity;

  // Evaluate all four movement directions
  for (let direction of DIRECTIONS) {

    let newX = column + direction.x;
    let newY = row + direction.y;

    if (!canAnimalMoveTo(newX, newY)) {
      continue;
    }

    let newDistance =
      nearestPredatorDistance(newX, newY);

    if (newDistance > bestDistance) {
      bestDistance = newDistance;
      safestMoves = [{ x: newX, y: newY }];

      } else if (newDistance === bestDistance) {
      safestMoves.push({ x: newX, y: newY });
      }
    }

  // No movement increases safety
  if (safestMoves.length === 0) {
    return { x: column, y: row };
  }

  // Randomly choose between equally safe directions
  return random(safestMoves);
  }
  
}

class Predator extends LivingThing {
  constructor() {
  super();
  this.cellType = "Predator";
  this.hunger = 0;
  this.hungerTreshold = 85;
  this.starvationTreshold = 115;

  this.reproductionTimer = 0;
  this.reproductionTreshold = 145;
  this.reproductionHungerLimit = 95;
  this.reproductionCost = 30;

  this.mateSearchRadius = 20;
  this.reproductionRadius = 2;
    
  this.moveChance = 0.4;
  this.huntingRadius = 10;
  this.attackRange = 1;

  this.wanderDestination = null;

  this.wanderMinDistance = 5;
  this.wanderMaxDistance = 15;  

  this.age = 0;
  this.maxLifespan = floor(random(750,851));
  } 

  updateHunger() {
    this.hunger++;
  }

  canEat() {
    return this.hunger >= this.hungerTreshold;
  }

  eat() {
    this.hunger = 0;
  }

  isStarving() {
    return this.hunger > this.starvationTreshold;
  }

  updateAge() {
    this.age++;
  }

  isOld() {
    return this.age > this.maxLifespan;
  }

  updateReproduction() {
    this.reproductionTimer++;
  }

  canReproduce() {
    return (
      this.reproductionTimer >= this.reproductionTreshold && this.hunger <= this.reproductionHungerLimit
    );
  }

  reproduce() {
    this.reproductionTimer = 0;
    this.hunger += this.reproductionCost;
  }

  getMovement(column, row) {

  // Priority 1 - Search for food.
  if (this.canEat()) {


  // callback function to findNearestTarget(). shorthand for a function that determines whether the .plant of a cell (in this case, inside findNearestTarget() passes in the cell parameter) is true or not
    
    let destination = findNearestTarget(
      column,
      row,
      cell => cell.animal !== null &&
      cell.animal.cellType === "Prey",
      this.huntingRadius,
      this.attackRange,
      nextCells
    );

    if (destination !== null) {
      return destination;
    }
  }

  // Priority 2 - Search for mates
  if (this.canReproduce()) {

    let destination = findNearestTarget(
      column,
      row,

      cell =>
        cell.animal !== null &&
        cell.animal !== this &&
        cell.animal.cellType === "Predator" &&    //Essentially same as above, but passing in multiple conditions.
        cell.animal.canReproduce(),

      this.mateSearchRadius,
      this.reproductionRadius,
      nextCells
    );

    if (destination !== null) {
      return destination;
    }
  }

  // Priority 3: Random walking
  return this.randomWalk(column, row);
}
}


//A constant array (won't be edited during runtime) containing objects of key-value pairs of "type" and "weight". Weight is the likelihood of it ebign spawned relative to the total weight.

const plantSpawnChance = 0.40;

const animalSpawnOptions = [
  { type: Prey, chance: 0.55 },
  { type: Predator, chance: 0.025 }
];